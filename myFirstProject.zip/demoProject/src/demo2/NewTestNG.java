package demo2;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeTest;
//import Question1.Page_Factory;
import org.testng.annotations.Test;

import demo2.Page_Factory;    //calling page factory for parameterization

public class NewTestNG {
	static FileInputStream fis;
	static XSSFWorkbook wb1;
	static Page_Factory pageFactory;
	static XSSFSheet sheet1;
	static WebDriver driver;
	static File src;
	
@BeforeClass
  public void fetch() throws IOException 
  {
		
		//data is picked from this XL sheet and passed on to the test script
	    src= new File("D:\\Afzal M4\\Afzal M4\\Afzal_Book1.xlsx");  
		System.out.println("File found");
		//using Java API specify workbook path
		fis = new FileInputStream(src);
		
		//to load entire workbook use XSSFWorkbook class
		wb1 = new XSSFWorkbook(fis);  //XSS used for .xlsx file
		
		//HSSFWorkbook wb1 = new HSSFWorkbook(fis); //HSS used for .xls file
		
		//to get the access of sheet 1 use XSSFSheet class
		sheet1 = wb1.getSheetAt(0);
		
		
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		driver = new ChromeDriver();
		pageFactory = PageFactory.initElements(driver, Page_Factory.class); 
		driver.get("D:\\example-javascript-form-validation.html");
		
  }
	@Test(priority=1)
	public void TestCaseOne() throws InterruptedException
    {
        //For User ID
		String userID=sheet1.getRow(1).getCell(0).getStringCellValue();
		System.out.println(userID);
		pageFactory.enter_userID(userID);
    }
	@Test(priority=2)
	public void TestCaseTwo() throws InterruptedException
    {
        //For User ID
		String userpass=sheet1.getRow(1).getCell(1).getStringCellValue();
		System.out.println(userpass);
		pageFactory.enter_password(userpass);
    }
	@Test(priority=3)
	public void TestCaseThree() throws InterruptedException
    {
        //For User ID
		String username=sheet1.getRow(1).getCell(2).getStringCellValue();
		System.out.println(username);
		pageFactory.enter_userName(username);
    }
	@Test(priority=4)
	public void TestCaseFour() throws InterruptedException
    {
        //For User ID
		String useradds=sheet1.getRow(1).getCell(3).getStringCellValue();
		System.out.println(useradds);
		pageFactory.enter_address(useradds);
    }

  }

