package demo4;

import org.openqa.selenium.Alert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.PageFactory;

/*
*
*@Author_Afzal
*
*/
public class Page_Factory {
	
	WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public Page_Factory(WebDriver driver)
	{
		this.driver =driver;
	}
	
	@FindBy(id="usrID")
	@CacheLookup // to store the element in cache memory
	WebElement userID;
	
	//using name for Password	
	@FindBy(how=How.NAME, using="passid")
	@CacheLookup
	WebElement password;
	
	//using ID for Name
	@FindBy(how=How.ID, using="usrname")
	@CacheLookup
	WebElement uName;
	
	//using Name
	@FindBy(how=How.XPATH, using="//*[@id='addr']")  //User address must have alphanumeric characters only
	@CacheLookup
	WebElement address;
	
	//using Name
	@FindBy(how=How.NAME, using="country")
	@CacheLookup
	WebElement Country;
	
	@FindBy(how=How.XPATH, using="/html/body/form/ul/li[12]/input")
	@CacheLookup // to store the element in cache memory
	WebElement zipCode;
	
	@FindBy(how=How.XPATH, using="/html/body/form/ul/li[14]/input")
	@CacheLookup // to store the element in cache memory
	WebElement eMail;
	
	@FindBy(how=How.XPATH, using="/html/body/form/ul/li[16]/input")
	@CacheLookup // to store the element in cache memory
	WebElement radioMale;
	
	@FindBy(how=How.XPATH, using="/html/body/form/ul/li[17]/input")
	@CacheLookup // to store the element in cache memory
	WebElement radioFemale;

	@FindBy(how=How.NAME, using="submit")
	WebElement submit;
	
	public void enter_userID(String uid)
	{
		userID.sendKeys(uid);
	}
	public void enter_password(String passcode)    //passcode is a formal parameter for Password web element only
	{
		password.sendKeys(passcode);
	}
	public void enter_userName(String name)    
	{
		uName.sendKeys(name);
	}
	public void enter_address(String adds)    
	{
		address.sendKeys(adds);
	}
	public void select_country(int index)    
	{
		
		Select sel= new Select(Country);
		sel.selectByIndex(index);
	}
	public void enter_zip(String zip)    
	{
		zipCode.sendKeys(zip);
	}
	public void enter_email(String mail)    
	{
		eMail.sendKeys(mail);
	}
	public boolean select_male(String male)
	{
		radioMale.click();
		return true;
	}
	public boolean select_female(String female)
	{
		radioFemale.click();
		return true;
	}
	
	
	public void verifyTitle(String expected_title) throws InterruptedException
	{
		Thread.sleep(2000);
		String actual_title = driver.getTitle();
		if(actual_title.contentEquals(expected_title))
		{
			System.out.println("Title Verification - Passed");
		}
		else
		{
			System.out.println("Title Verification - Failed");
			driver.quit();
		}
			
	}
	//User ID block
	public void verifyuserID() throws InterruptedException  
	{
		
		Boolean uID=userID.isDisplayed();
		// Verifying availability of User ID text box
		if(uID==true) 
		{
			
			System.out.println("User ID textbox present");
			enter_userID("");
			
			submit.click();
			Thread.sleep(3000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="User Id should not be empty / length be between 5 to 12";
		    String actualAlertMessage= driver.switchTo().alert().getText();
		  //6. Ensure that the alert box displays the message �User Id should not be empty / length be between 5 to 12� 
			//upon clicking on the link �Submit� without entering any data in the text box.
		    if(expectedAlertMessage.contentEquals(actualAlertMessage))
		    {
		    	System.out.println("Alert message verification for user id - Passed");
		    	alert.accept();
		    	//5. Enter value for user ID
		    	enter_userID("Mark001");
		    	
		    }
		    else
		    {
		    	System.out.println("Alert message verification for user id - Failed");
			}
		    
		}
		else
		{
			System.out.println("User ID textbox not present");
		}
		
	}
	
	//Password block
	public void verifyPassword() throws InterruptedException  
	{
		System.out.println("In here");
		Boolean pswd=password.isDisplayed();
		// Verifying availability of Password text box
		if(pswd==true) 
		{
			
			System.out.println("Password textbox present");
			enter_password("");
			
			submit.click();
			
			Thread.sleep(3000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="Password should not be empty / length be between 7 to 12";
		    String actualAlertMessage= driver.switchTo().alert().getText();
		    //8. Ensure that the alert box displays the message �Password should not be empty / length be between 7 to 12� 
			//upon clicking on the link �Submit� without entering any data in the text box.
		    if(expectedAlertMessage.contentEquals(actualAlertMessage))
		    {
		    	System.out.println("Alert message verification for Password - Passed");
		    	alert.accept();
		    	//7. Enter value for Password
		    	enter_password("facebook001");
		    }
		    else
		    {
		    	System.out.println("Alert message verification for Password - Failed");
			}
		    
		}
		else
		{
			System.out.println("Password textbox not present");
		}
		
	}
	
	//Name block
	public void verifyName() throws InterruptedException  
	{
		System.out.println("In here");
		Boolean name=uName.isDisplayed();
		// Verifying availability of Name text box
		if(name==true) 
		{
			
			System.out.println("Name textbox present");
			enter_userName("");
			
			submit.click();
			
			Thread.sleep(3000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="Username must have alphabet characters only";
		    String actualAlertMessage= driver.switchTo().alert().getText();
		    //8. Ensure that the alert box displays the message �Username must have alphabet characters only� 
			//upon clicking on the link �Submit� without entering any data in the text box.
		    if(expectedAlertMessage.contentEquals(actualAlertMessage))
		    {
		    	System.out.println("Alert message verification for Name - Passed");
		    	alert.accept();
		    	//9. Enter value for Name
		    	enter_userName("MarkZuckerberg");
		    }
		    else
		    {
		    	System.out.println("Alert message verification for Name - Failed");
			}
		    
		}
		else
		{
			System.out.println("Name textbox not present");
		}
		
	}
	
	//Address block
	public void verifyAddress() throws InterruptedException  
	{
		System.out.println("In here");
		Boolean adds=address.isDisplayed();
		// Verifying availability of Address text box
		if(adds==true) 
		{
			
			System.out.println("Address textbox present");
			enter_address("");
			
			submit.click();
			
			Thread.sleep(3000);
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="User address must have alphanumeric characters only";
		    String actualAlertMessage= driver.switchTo().alert().getText();
		    //10. Ensure that the alert box displays the message �User address must have alphanumeric characters only� 
			//upon clicking on the link �Submit� without entering any data in the text box.
		    if(expectedAlertMessage.contentEquals(actualAlertMessage))
		    {
		    	System.out.println("In here");
		    	System.out.println("Alert message verification for Address - Passed");
		    	alert.accept();
		    	//11. Enter value for Address
		    	enter_address("NewDelhiAurangzebRoad");
		    }
		    else
		    {
		    	System.out.println("Alert message verification for Address - Failed");
			}
		    
		}
		else
		{
			System.out.println("Address textbox not present");
		}
		
	}
	
	//Country block
	public void verifyCountry() throws InterruptedException  

	{
		System.out.println("In here");
		Boolean cnty=Country.isDisplayed();
		// Verifying availability of Country text box
		if(cnty==true) 
		{
			
			System.out.println("Country select box present");
		
			submit.click();
			
			Thread.sleep(3000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="Select your country from the list";
		    String actualAlertMessage= driver.switchTo().alert().getText();
		    //10. Ensure that the alert box displays the message �Username must have alphabet characters only� 
			//upon clicking on the link �Submit� without entering any data in the text box.
		    if(expectedAlertMessage.contentEquals(actualAlertMessage))
		    {
		    	System.out.println("Alert message verification for Country - Passed");
		    	alert.accept();
		    	//Select Country
		    	select_country(2);	
		    }
		    else
		    {
		    	System.out.println("Alert message verification for Country- Failed");
			}
		    
		}
		else
		{
			System.out.println("Country textbox not present");
		}
		
	}
	
	//Zip code block
		public void verifyZip() throws InterruptedException  

		{
			System.out.println("In here");
			Boolean zip=zipCode.isDisplayed();
			// Verifying availability of Country text box
			if(zip==true) 
			{
				
				System.out.println("Zip code text box present");
			
				submit.click();
				
				Thread.sleep(3000);;
				Alert alert = driver.switchTo().alert();
				String expectedAlertMessage="ZIP code must have numeric characters only";
			    String actualAlertMessage= driver.switchTo().alert().getText();
			    //10. Ensure that the alert box displays the message �Username must have alphabet characters only� 
				//upon clicking on the link �Submit� without entering any data in the text box.
			    if(expectedAlertMessage.contentEquals(actualAlertMessage))
			    {
			    	System.out.println("Alert message verification for Zip Code - Passed");
			    	alert.accept();
			    	//Select Zip code
			    	enter_zip("35410");	
			    }
			    else
			    {
			    	System.out.println("Alert message verification for Zip Code- Failed");
				}
			    
			}
			else
			{
				System.out.println("Zip code textbox not present");
			}
			
		}
		
		//email block
		public void verifyEmail() throws InterruptedException  
		{
			System.out.println("In here");
			Boolean mail=eMail.isDisplayed();
			// Verifying availability of Email text box
			if(mail==true) 
			{
				
				System.out.println("email textbox present");
				enter_email("");
				
				submit.click();
				
				Thread.sleep(3000);;
				Alert alert = driver.switchTo().alert();
				String expectedAlertMessage="You have entered an invalid email address!";
			    String actualAlertMessage= driver.switchTo().alert().getText();
			    //8. Ensure that the alert box displays the message �You have entered an invalid email address!� 
				//upon clicking on the link �Submit� without entering any data in the text box.
			    if(expectedAlertMessage.contentEquals(actualAlertMessage))
			    {
			    	System.out.println("Alert message verification for e-Mail - Passed");
			    	alert.accept();
			    	//9. Enter value for email
			    	enter_email("someone@gmail.com");
			    }
			    else
			    {
			    	System.out.println("Alert message verification for e-Mail - Failed");
				}
			    
			}
			else
			{
				System.out.println("e-Mail textbox not present");
			}
			
		}
}