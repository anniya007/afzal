package demo4;

import java.io.File;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;







//Object Repository
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;


//import org.testng.annotations.Test;

/*import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;*/
import demo4.Page_Factory;

public class ReadPropertyFile_NG {
	
	static WebDriver driver;
	static String str;
	static FileInputStream fis ;
	static Properties pro;
	static Page_Factory pageFactory;
	@BeforeClass
	public static void fetch() throws IOException, InterruptedException
	{
		// to access property file
		File src= new File("D:/Afzal M4/POM/Propertyfile.txt");
		FileInputStream fis = new FileInputStream(src);
		//to read the property file create an object of properties class
		Properties pro= new Properties();
		//to load property file
		pro.load(fis);
		// to fetch the key value from property file
		String str= pro.getProperty("url"); //url=https://demo.opencart.com/
		System.out.println(str);
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		pageFactory = PageFactory.initElements(driver, Page_Factory.class); 
		driver.get("D:\\example-javascript-form-validation.html");
	}
	/*@Test
	public void TestCaseOne() throws InterruptedException
    {
        //For User ID
		System.out.println(userID);
		pageFactory.enter_userID(userID);
    }*/
}
	


