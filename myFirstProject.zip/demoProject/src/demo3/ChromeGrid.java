package demo3;
//with latest chrome driver and browsers
//jar 2.47 has been used
//Afzal Khan
import java.net.MalformedURLException;

import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class ChromeGrid
{
	public static void main(String[] args) throws InterruptedException, MalformedURLException 

	{
		//with latest chrome driver and browsers
		System.setProperty("webdriver.chromedriver.driver", "D:/chromedriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setBrowserName("chrome");
		capabilities.setCapability("webdriver.chromedriver.driver", "D:/chromedriver.exe");
			
		capabilities.setPlatform(Platform.WINDOWS);
		//capabilities.setVersion(version);
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
try {
		driver.get("D:\\example-javascript-form-validation.html");
		System.out.println(driver.getTitle());
		
//		driver.quit();
}
catch(Exception ex){
	System.out.println("Hello");
}
//driver.quit();
	}
}
