package demo3;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class ExplorerSGrid 
{
	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		System.setProperty("webdriver.ie.driver","D:/IEDriverServer.exe");

		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);

		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub") , caps);
		try{
		driver.get("http://demo.opencart.com/");
		System.out.println(driver.getTitle());
		//System.out.println(driver.getCurrentUrl());
		Thread.sleep(500);
		//driver.quit();
		}
		catch(Exception e)
			
		{
				
		}
	}
}
