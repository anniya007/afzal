package ObjectRepository;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
//Object Repository







import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
/*import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

*/public class ReadPropertyFile {
	
	static WebDriver driver;
	static String str;
	public static void main(String args[]) throws Exception
	{
		// to access property file
		File src= new File("D:/Afzal M4/POM/Propertyfile.txt");
		FileInputStream fis = new FileInputStream(src);
		//to read the property file create an object of properties class
		Properties pro= new Properties();
		//to load property file
		pro.load(fis);
		// to fetch the key value from property file
		str= pro.getProperty("url");
		
		String str= pro.getProperty("url"); //url=https://demo.opencart.com/

		System.out.println(str);

		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(str);
		Thread.sleep(5000);
	
		
	}
}
	


