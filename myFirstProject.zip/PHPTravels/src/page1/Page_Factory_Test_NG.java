package page1;

//testNG program

//import java.util.concurrent.TimeUnit;
//
//import junit.framework.Assert;
//
//import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
//import org.testng.annotations.BeforeTest;
//import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import page1.Page_Factory;

public class Page_Factory_Test_NG {
	
	WebDriver driver ;
	Page_Factory pageFactory;
	public int TimeoutValue = 30;
			
	@Test(priority=1)
	public void TestCaseOne() throws InterruptedException
	{
		//1.	Launching the application browser, Chrome
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		//2.	Open the web page �Registration Form.html � in the browser.
		driver.get("http://www.phptravels.net/cars/search?pickupLocation=7&dropoffLocation=7&pickupDate=01%2F11%2F2018&pickupTime=02%3A00&dropoffDate=02%2F11%2F2018&dropoffTime=04%3A30");
		pageFactory = PageFactory.initElements(driver, Page_Factory.class);
	
		
	}         
	/*@Test(priority=2)
	public void TestCaseTwo() throws InterruptedException
	{
        //For Cars button click
		pageFactory.verifyButtonClick();
		
        //For Time1
		pageFactory.verifytime1();
		
        //For Time2
		pageFactory.verifytime2();
	}*/
	@Test(priority=2)
	public void TestCaseTwo() throws InterruptedException
	{
        //For Cars button click
		pageFactory.verifystarGrade();
		
        //For Time1
		pageFactory.verifypriceRange();
		
        //For Time2
		//pageFactory.verifyairportPickUp();
	}
}