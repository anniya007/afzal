/*******Author Name: Afzal JV Emp Id : 158017 Date: 28.9.2018 ******/
//Purpose: To provide test cases of Video Management

package com.cg.Videomgmt.junit;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.Videomgmt.bean.VideoDetails;
import com.cg.Videomgmt.exception.VideoException;
import com.cg.Videomgmt.helper.CollectionHelper;

public class CollectionHelperTest
{
	static CollectionHelper collectionHelper;
	static VideoDetails all=null;

	//adding asset details to the array list
	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new CollectionHelper();
		all=new VideoDetails(3,"Wings of Fire","Story",12);		
	}
	
	//clearing the arraylist
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		all=null;
	}	
	
	//checking whether asset details are present in array list
	@Test 
	public void testAddNewVideo() throws VideoException
	{
		collectionHelper.addNewVideo(all);
		Assert.assertNotNull(all.getReferenceId());
	}

}