package com.cg.Videomgmt.junit;

import org.testng.annotations.Test;

public class CollectionHelperTestTest {

  @Test
  public void afterClass() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void beforeClass() {
    throw new RuntimeException("Test not implemented");
  }
}
