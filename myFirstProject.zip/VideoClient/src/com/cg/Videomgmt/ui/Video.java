/*******Author Name: Afzal JV Emp Id : 158017 Date: 28.9.2018 ******/
//Purpose: To provide user interface of Video Management for accepting & displaying Video details

package com.cg.Videomgmt.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.Videomgmt.bean.VideoDetails;
import com.cg.Videomgmt.exception.VideoException;
import com.cg.Videomgmt.helper.CollectionHelper;
import com.cg.Videomgmt.helper.DataValidator;

public class Video 
{
	static Scanner sc=new Scanner(System.in);
	static CollectionHelper collectionhelper=null;
	
	//Main method
	public static void main(String[] args)
	{
		String choice;
		collectionhelper=new CollectionHelper();

		while(true)
		{
			//Providing user interface
			System.out.println("Video Management \n***************** \n1. Insert Video details\n"
					+ "2. Display all Videos\n"+ "3. Exit From System");
			
			System.out.println("\nEnter your choice :");
			choice=sc.next();
			switch(choice)
			{
			
			//Calling enterVideoDetails method for getting & displaying Video details 
			case "1":enterVideoDetails();break;
			case "2":collectionhelper.displayAllVideos();break;
			case "3":System.out.println("Exiting...");System.exit(0);
			default: System.out.println("Please enter correct choice");
			break;
			}
		}
	}
	
	//method for getting & displaying Video details
	private static void enterVideoDetails() 
	{
		System.out.println("Enter Video Name:");
		String VideoName=sc.next();
		try 
		{
			//sending input to validateVideoName method for validating Video type
			if(DataValidator.validateVideoName(VideoName))
			{
				System.out.println("Enter Video Type:");
				String VideoType=sc.next();
				//sending input to validateVideoType method for validating Video name
				if(DataValidator.validateVideoType(VideoType))
				{
					System.out.println("Enter Video Quantity:");
					String qty=sc.next();
										
					//sending input to validateVideoQuanity method for validating Video quantity
					if(DataValidator.validateVideoQuanity(qty))
					{
												
						//Generate  Random Reference Id
						Random ran=new Random();
						long refId=ran.nextInt();
						int quantity = Integer.parseInt(qty);

						//sending valid input data to the constructor of VideoDetails class
						VideoDetails cc=new VideoDetails(VideoName,VideoType, quantity);
						//adding valid input data of Video details to the array list
						collectionhelper.addNewVideo(cc);
						//displaying all the existing Video details of the arrary list
						collectionhelper.displayAllVideos();
					}
					}	
				}
			
		} 
		catch (VideoException e)
		{			
			System.out.println(e.getMessage());
		}		

	}
}
