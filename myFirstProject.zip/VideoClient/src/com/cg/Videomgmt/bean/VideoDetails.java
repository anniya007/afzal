/*******Author Name: Afzal JV Emp Id : 158017 Date: 28.9.2018 ******/
//Purpose: To provide getters and setters for Video details

package com.cg.Videomgmt.bean;

import java.io.Serializable;

//import java.time.LocalDate;

public class VideoDetails implements Serializable {

	int[] a={3,4,5,6};
	private long ID;
	private String VideoName;
	private String VideoType;
	private int quantityVideo;

	//default constructor
	public VideoDetails() {

	}
	
	//initializing instance variables
	public VideoDetails(String VideoName, String VideoType,int quantityVideo) {
		
		this.VideoName = VideoName;
		this.VideoType = VideoType;
		this.quantityVideo = quantityVideo;

	}
	
	//getter for ID
		public void getID(int ID) {
			this.ID = ID;
		}
		//setter for ID
				public long setID() {
					return ID;
				}
	//getter for Video name
	public String getVideoName() {
		return VideoName;
	}
	//setter for Video name
	public void setVideoName(String VideoName) {
		this.VideoName = VideoName;
	}
	//getter for Video type
	public String getVideoType() {
		return VideoType;
	}
	//setter for Video type
	public void setVideoType(String VideoType) {
		this.VideoType = VideoType;
	}
	//getter for Video quantity
	public void getQuantityVideo(int quantityVideo) {
		this.quantityVideo = quantityVideo;
	}
	//setter for Video quantity
		public int setQuantityVideo() {
			return quantityVideo;
	}
	
	//displaying Video details 
	public void ddisplay() {
		System.out.println("Asset [Id=" + ID + ", Video Name=" + VideoName + ", Video Type=" + VideoType +", Quantity=" + "quantityVideo]") ;
	}
}
