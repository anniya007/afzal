/*******Author Name: Afzal JV Emp Id : 158017 Date: 28.9.2018 ******/
//Purpose: To create arraylist for adding & displaying Video details

package com.cg.Videomgmt.helper;

//import java.util.HashSet;
import java.util.Iterator;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.*;

import com.cg.Videomgmt.bean.VideoDetails;

public class CollectionHelper
{
	public CollectionHelper(){}
	
	//adding Video details to the array list
	public void addNewVideo(VideoDetails VideoDetails) 
	{			
		try{
			FileOutputStream fos= new FileOutputStream("mark1.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(VideoDetails);
			oos.close();
			fos.close();
		}
		catch (IOException e)
		{	
		}
	}
	//displaying all Video details
	public void displayAllVideos()
	{
		try{
			FileInputStream fis= new FileInputStream("mark1.txt");
		
		  ObjectInputStream ois = new ObjectInputStream(fis);
		  VideoDetails s2= new VideoDetails();
		  s2=(VideoDetails)ois.readObject();
		  s2.ddisplay();
		  ois.close();
		  fis.close();	  
		}
		catch(IOException e)
		{
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
