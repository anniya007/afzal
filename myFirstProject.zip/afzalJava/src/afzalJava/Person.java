//Refer the class diagram given below and create person class.

package afzalJava;

public class Person {
	String firstName, lastName;
	char gender;

	   public Person(){
		   
	   }
	   
	   public Person(String firstName, String lastName, char gender){
	    	this.firstName=firstName;
	    	this.lastName=lastName;
	    	this.gender=gender;
	    }
		//getter for First Name
		public String getfirstName() {
			return firstName;
		}
		//setter for First Name
		public void setlastName(String lastName) {
			this.lastName = lastName;
		}
		//getter for Last Name
		public String getlastName() {
			return lastName;
		}
		//setter for Last Name
		public void setfirstName(String lastName) {
			this.lastName = lastName;
		}
		//getter for gender
		public String getGender() {
			return lastName;
		}
		//setter for gender
		public void setgender(char gender) {
			this.gender = gender;
		}

}


