
/*
 * Write a program to accept a number from user as a command line 
 * argument and check whether the given number is positive or negative number.
 */
package afzalJava;
import java.util.Scanner;

public class natureOfNumber {
	public static void main(String [] args)
	{
		 Scanner scan = new Scanner(System.in);
		 
		 System.out.println("Enter any number :");
		 int number = scan.nextInt();
		 
		  if(number>0)
		 {
			 System.out.println("Entered number is Positve");
		 }
		  else
			  
			  System.out.println("Entered number is Negative");
	}
	
}
