/*Write a java program to print person details in the format as shown below:
Person Details:
____________
First Name: Divya
Last Name: Bharathi
Gender: F
Age: 20
Weight: 85.55 */
	
package afzalJava;

public class personalDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Using Scanner for Getting Input from User 
		System.out.println("Person Details:");
		System.out.println("________________");
		System.out.println("First name: Divya");
		System.out.println("Last Name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 85.55");
			
	}

}
