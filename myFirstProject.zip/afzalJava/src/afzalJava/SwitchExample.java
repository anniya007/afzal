package afzalJava;
import java.util.Scanner;

public class SwitchExample {

	/*
	 @afzalbegam args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 0, 1 or 2");
		int i = scan.nextInt();
	    switch (i) {

	    case 0:
	      System.out.println("i is 0"); //break statement missing
	      break;  //break statement inserted
	    case 1:
	      System.out.println("i is 1");
	      break;  //break statement inserted
	    case 2:
	      System.out.println("i is 2");
	      break;  //break statement inserted
	    default:
	      System.out.println("Free flowing switch example!");

	    }
	}
}
