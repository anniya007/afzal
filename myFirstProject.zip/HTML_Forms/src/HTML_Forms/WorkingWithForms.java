package HTML_Forms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WorkingWithForms {

	public static void main(String[] args) 
	{
		//Step 1 launch browser
	       WebDriver driver= new FirefoxDriver();
	       
	     //step-2 navigate to APP/URL
	       driver.get("file:///D:/Afzal%20M4/PaymentDetails.html");
	       
	   	driver.findElement(By.name("txtUName")).sendKeys("afzal123");	
		driver.findElement(By.id("txtPassword")).sendKeys("selenium*");
		driver.findElement(By.xpath(".//*[@id='txtConfPassword']")).sendKeys("selenium*");
	   	driver.findElement(By.name("txtUName")).sendKeys("afzal123");	
		driver.findElement(By.id("txtPassword")).sendKeys("selenium*");
		driver.findElement(By.xpath(".//*[@id='txtConfPassword']")).sendKeys("selenium*"); 
	       // TODO Auto-generated method stub

	}

}
