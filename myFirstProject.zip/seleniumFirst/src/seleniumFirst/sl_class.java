package seleniumFirst;
//import java.awt.Point;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.remote.DesiredCapabilities;
//import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class sl_class 
{
	static WebDriver driver;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//step 1 open browser
			
//		System.setProperty("webdriver.chrome.driver","D:\\shashi\\m4\\chromedriver.exe");
//		
//		WebDriver driver=new ChromeDriver();
		
		//navigate to app /url
		
		//driver.get("https:\\demo.opencart.com");
		

		
		driver.get("file:///C:/Users/skuma545/Documents/My%20Received%20Files/ConferenceRegistartion.html");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	
		//to identify the elements 
		
		WebElement element=driver.findElement(By.id("txtFirstName"));
		
		element.sendKeys("Shashi");
		
		element=driver.findElement(By.id("txtLastName"));
		
		element.sendKeys("kumar");
		
		element=driver.findElement(By.id("txtEmail"));
		
		element.sendKeys("shashikumar@b.com");
		
		element=driver.findElement(By.name("Phone"));
		
		element.sendKeys("9876543210"); //html/body/form/table/tbody/tr[14]/td/a
		
		element=driver.findElement(By.xpath("//html/body/form/table/tbody/tr[14]/td/a"));
		
		//driver.findElement(By.linkText("next")).click();
//		
//		WebElement sizeElement=driver.findElement(By.name("size"));
//			
//		System.out.println("\nheading h2"+driver.findElement(By.xpath("//h2")).getText()+"\n");
//		
//		System.out.println("title :"+driver.getTitle()+"\nCurrent url : "+driver.getCurrentUrl());
//		
//		Select sel=new Select(sizeElement);
//		
//		sel.selectByIndex(1);
//		
		
		
		//driver.manage().window().setPosition(new Point("50,50"));
		
		String attrb=element.getAttribute("name");
		
		System.out.println("Name of the button is : "+attrb);
		
		element.click();
		
		
		// Explitlty waiting for alert to be visible
		
		WebDriverWait wait=new WebDriverWait(driver, 5);
		
		wait.until(ExpectedConditions.alertIsPresent());
		
		Alert alt=driver.switchTo().alert();
		
		System.out.println("alert\n"+alt.getText());
		
		//driver.close();
	}

}