package seleniumFirst;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SampleConferenceRegistration 
{
	WebDriver driver;
	By firstName= By.xpath("//*[@id='txtFirstName']");
	By lastName = By.xpath("//*[@id='txtPassword']");
	By email= By.xpath("/html/body/h1");
	

}
