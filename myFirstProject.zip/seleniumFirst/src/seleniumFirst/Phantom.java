package seleniumFirst;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

public class Phantom 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("phantomjs.binary.path","D:\\phantomjs.exe");
		WebDriver driver=new PhantomJSDriver();
		driver.get("file:///D:/Afzal%20M4/PaymentDetails.html");
		System.out.println("page tiltle is: "+driver.getTitle());
		//driver.findElement(By.name("txtLN")).sendKeys("Afzal");
		System.out.println(driver.getCurrentUrl());
		
		/*WebElement nextLink=driver.findElement(By.name("txtLN")); driver.findElement(By.name("txtLN")).sendKeys("Khan");	
	   String name = nextLink.getText();
	   System.out.println(name);*//*
		driver.findElement(By.name("txtLN")).sendKeys("Khan");
		String lastname=selenium.getValue("//*[@id='lastName']");
		System.out.println(lastname);*/
		  WebElement fName=driver.findElement(By.name("txtLN"));
		  fName.sendKeys("Admin");
		  String lastname=fName.getText();
		  System.out.println(lastname);

//		driver.findElement(By.id("txtDebit")).sendKeys("254125753");
//		driver.findElement(By.name("cvv")).sendKeys("354");
//		driver.findElement(By.id("txtMonth")).sendKeys("12");
//		driver.findElement(By.name("year")).sendKeys("19");
//		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td/input")).click();

	}

}

