package seleniumFirst;
//
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class selenium_class2 {
	public static FirefoxDriver driver;
	public static void main(String[] args) throws InterruptedException {
		//Step 1 launch browser
	      //
	
		System.setProperty("webdriver.firefox.bin","C:\\Users\\afzalkha\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", "false");
		//FirefoxOptions options = new FirefoxOptions();
		driver = new FirefoxDriver();
		
		
		//step-2 navigate to APP/URL
		driver.get("file:///D:/Afzal%20M4/ConferenceRegistartion.html");
		
		//step-3 detect elements on the web page
		driver.findElement(By.cssSelector("#txtFirstName")).sendKeys("Afzal");
		driver.findElement(By.name("txtLN")).sendKeys("Khan");	
		driver.findElement(By.id("txtEmail")).sendKeys("someone@gmail.com");
		driver.findElement(By.xpath("//*[@id='txtPhone']")).sendKeys("9130429476");
		
		Select number=new Select(driver.findElement(By.name("size")));
		number.selectByIndex(1);  //marking second selection
				
		driver.findElement(By.cssSelector("body > form > table > tbody > tr:nth-child(5) > td:nth-child(2) > select > option:nth-child(2)"));
		driver.findElement(By.name("Address")).sendKeys("Raj Marg");
		driver.findElement(By.name("Address2")).sendKeys("Delhi main road");
		
	    
		Select dropdown = new Select(driver.findElement(By.name("city")));
		dropdown.selectByVisibleText("Bangalore");
		
		Select dropdown2 = new Select(driver.findElement(By.name("state")));
		//dropdown2.selectByVisibleText("Karnataka");  //both are possible
		dropdown2.selectByIndex(2);
		
		
		WebElement  radioBtn = driver.findElement (By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
		radioBtn.click();
		Thread.sleep(10000);
/*		WebElement  radioBtn2 = driver.findElement (By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
		radioBtn2.click();*/
		
		driver.findElement(By.linkText("Next")).click();
		
		//Thread.sleep(2000);//delay the execution of the script irrespective of the element status
		//now make use of implicit wait
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//maximum timeout seconds
		//wait till alert is present
		WebDriverWait wait= new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.alertIsPresent());
		
		//switch to alert
		//driver.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td/input")).click();
		

		
		}

}
