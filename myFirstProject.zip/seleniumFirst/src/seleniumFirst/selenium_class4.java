package seleniumFirst;
/*firefox with proxy for live site
Firefox version 30.0

*/
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

public class selenium_class4 {

	private static String baseUrl;

	public static void main(String[] args) throws InterruptedException
	{
		//Step 1 launch browser
		System.setProperty("webdriver.firefox.bin","C:\\Users\\afzalkha\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("network.proxy.type",1);
		profile.setPreference("network.proxy.http","10.219.96.26");//proxy for firefox
		profile.setPreference("network.proxy.http_port",8080);
		profile.setPreference("network.proxy.ssl","10.219.96.26");
		profile.setPreference("network.proxy.ssl_port",8080);
     	WebDriver driver = new FirefoxDriver(profile);
		
     	//step-2 navigate to APP/URL
		baseUrl ="https://www.google.co.in/";
		driver.get(baseUrl);

		//
	
	}

}
