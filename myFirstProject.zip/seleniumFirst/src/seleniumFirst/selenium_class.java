package seleniumFirst;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class selenium_class {

	public static void main(String[] args) {
	//Step 1 launch browser
       WebDriver driver= new FirefoxDriver();
       //System.setProperty("webdriver.chrome.driver","D:\\Selenium Jars\\chromedriver.exe");
       //System.setProperty("webdriver.fierfox.bin","C:\\Users\\afzalkha\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
	//WebDriver driver= new ChromeDriver();
	//step-2 navigate to APP/URL
	//driver.get("file:///D:/Afzal%20M4/PaymentDetails.html");
	//driver.get("https://www.google.co.in/");
	driver.get("file:///D:/Afzal%20M4/PaymentDetails.html");
	//step-3 
	
	WebElement firstName=driver.findElement(By.cssSelector("#txtFirstName"));
	firstName.sendKeys("");
	WebElement nextLink=driver.findElement(By.cssSelector("#txtFirstName"));
	nextLink.click();
	
	//waiting for the alert box to be visible
	
	WebDriverWait wait = new WebDriverWait(driver,5);
	wait.until(ExpectedConditions.alertIsPresent());
	
	//switch to alert
	Alert alt=driver.switchTo().alert();
	String expectedResult= "Registarion successful!!!";
	String altxtactualTest=alt.getText();
	if(altxtactualTest.equals(expectedResult))
	{
		System.out.println("Test Passed");
	} 
	/*
	driver.findElement(By.name("txtLN")).sendKeys("Khan");	
	driver.findElement(By.id("txtDebit")).sendKeys("254125753");
	driver.findElement(By.name("cvv")).sendKeys("354");
	driver.findElement(By.id("txtMonth")).sendKeys("12");
	driver.findElement(By.name("year")).sendKeys("19");
	

	//Thread.sleep(2000);//delay the execution of the script irrespective of the element status
	//now make use of implicit wait
	//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//maximum timeout seconds
//	WebDriverWait wait= new WebDriverWait(driver, 10);
//	wait.until(ExpectedConditions.alertIsPresent());
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td/input")).click();
	

//	alt.accept(); //Register button pressed
//	alt.dismiss(); //to ESC
	//Thread.sleep(1000);
    //driver.switchTo().alert().accept();
	//driver.quit();
	*/
	
	}

}
