/*
Invoking Internet Explorer
IE version 11
*/
package seleniumFirst;
/*import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;*/
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class selenium_class3
{
	static String driverPath = "D:\\Slenium Lib\\";
	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.ie.driver",driverPath+"IEDriverServer.exe"); //helps pick the browser driver
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer(); 
		
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
		
		WebDriver driver = new InternetExplorerDriver(caps);	
		driver.get("https://demo.opencart.com/");
		System.out.println(driver.getTitle());
		Thread.sleep(2000);
		//driver.close();
    		     		
     	}  
}	
