package seleniumFirst;

import org.openqa.selenium.By;


public class PaymentClass extends selenium_class2
{
	
	public void setup()
	{
	
	    driver.get("file:///D:/Afzal%20M4/PaymentDetails.html");
		//step-3 
		driver.findElement(By.name("txtLN")).sendKeys("Afzal");
		driver.findElement(By.name("txtLN")).sendKeys("Khan");	
		driver.findElement(By.id("txtDebit")).sendKeys("254125753");
		driver.findElement(By.name("cvv")).sendKeys("354");
		driver.findElement(By.id("txtMonth")).sendKeys("12");
		driver.findElement(By.name("year")).sendKeys("19");
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td/input")).click();
	 }
}