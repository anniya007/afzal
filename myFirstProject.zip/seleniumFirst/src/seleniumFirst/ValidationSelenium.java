package seleniumFirst;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ValidationSelenium 

{
	static String expected_result;
	static String actual_result;
	public static void main(String[] args) {
;
	
	 WebDriver driver= new FirefoxDriver();
	
	WebElement firstName= driver.findElement(By.cssSelector("#txtFirstName"));
	firstName.sendKeys("");
	WebElement nextLink=driver.findElement(By.cssSelector("#txtFirstName"));
	nextLink.click();
	}

}
