package Excel;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class hello {
	static XSSFWorkbook wb1;
	static XSSFSheet sheet1;
	WebDriver driver;
	public static void main(String[] args) throws Exception {
		File src= new File("D:\\Data1.xlsx");
		//using Java API specify workbook path
		FileInputStream fis = new FileInputStream(src);
		//to load entire workbook use XSSFWorkbook class
		XSSFWorkbook wb1 = new XSSFWorkbook(fis);  
		
		XSSFSheet	 sheet1 = wb1.getSheetAt(0);
		
				
		String firstname=sheet1.getRow(2).getCell(0).getStringCellValue();
		String lastname=sheet1.getRow(2).getCell(1).getStringCellValue();
		String email=sheet1.getRow(1).getCell(2).getStringCellValue();
		String number=sheet1.getRow(1).getCell(3).getStringCellValue();
		
		
		System.out.println(firstname);
		System.out.println(lastname);
		System.out.println(email);
		System.out.println(number); 
		
		
		System.setProperty("webdriver.chrome.driver","D:\\m4 folder\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/llingam/Desktop/m4/ConferenceRegistartion.html");
		driver.findElement(By.id("txtFirstName")).sendKeys(firstname);
		driver.findElement(By.id("txtLastName")).sendKeys(lastname);
		driver.findElement(By.xpath(".//*[@id='txtEmail']")).sendKeys(email);
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys(number);
//		driver.findElement(By.id("pass")).sendKeys(password);
//		driver.findElement(By.id("login")).click();
		//driver.close();
		//wb1.close();  
	}
	public void readdata(XSSFWorkbook wb1,XSSFSheet sheet1,WebDriver driver) throws InterruptedException
	
	{
		String firstname=sheet1.getRow(2).getCell(0).getStringCellValue();
		String lastname=sheet1.getRow(2).getCell(1).getStringCellValue();
//		String email=sheet1.getRow(1).getCell(2).getStringCellValue();
//		String number=sheet1.getRow(1).getCell(3).getStringCellValue();
		
		
		System.out.println(firstname);
		System.out.println(lastname);
//		System.out.println(email);
//		System.out.println(number); 
		
		
		System.setProperty("webdriver.chrome.driver","D:\\m4 folder\\chrome\\chromedriver.exe");
	    driver = new ChromeDriver();
		driver.get("file:///C:/Users/llingam/Desktop/m4/ConferenceRegistartion.html");
		driver.findElement(By.id("txtFirstName")).sendKeys(firstname);
		driver.findElement(By.id("txtLastName")).sendKeys(lastname);
//		driver.findElement(By.xpath(".//*[@id='txtEmail']")).sendKeys(email);
//		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys(number);
		Thread.sleep(3000);
		driver.close();
	}

}
