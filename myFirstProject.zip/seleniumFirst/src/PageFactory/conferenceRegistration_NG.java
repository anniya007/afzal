package PageFactory;

//testNG program

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

//import Lokesh.LoginPage;
//import pagefactory.conferenceRegistration;

public class conferenceRegistration_NG {
	
	WebDriver driver ;
	conferenceRegistration login_page;

	public int TimeoutValue = 30;
	@BeforeClass
	public void verifylogin()
	{
/*		System.setProperty("webdriver.chrome.driver","D:\\m4 folder\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("C:\\Users\\llingam\\Desktop\\m4\\ConferenceRegistartion.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		System.out.println("chrome browser is opened");
		conferenceRegistration login_page = PageFactory.initElements(driver, conferenceRegistration.class);*/
		System.setProperty("webdriver.chrome.driver","D:\\m4 folder\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("C:\\Users\\llingam\\Desktop\\m4\\ConferenceRegistartion.html");
		System.out.println("beforetest");
	}
	
	@BeforeTest
	public void test()
	{

/*		System.setProperty("webdriver.chrome.driver","D:\\m4 folder\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("C:\\Users\\llingam\\Desktop\\m4\\ConferenceRegistartion.html");
		System.out.println("beforetest");*/
		System.setProperty("webdriver.chrome.driver","D:\\m4 folder\\chrome\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("C:\\Users\\llingam\\Desktop\\m4\\ConferenceRegistartion.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		System.out.println("chrome browser is opened");
		conferenceRegistration login_page = PageFactory.initElements(driver, conferenceRegistration.class);
	}
	
	
	
	@Test
	public void veryfylogin()
	{
//	System.setProperty("webdriver.chrome.driver","D:\\m4 folder\\chrome\\chromedriver.exe");
//		WebDriver driver = new ChromeDriver();
//		driver.get("C:\\Users\\llingam\\Desktop\\m4\\ConferenceRegistartion.html");
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		driver.manage().window().maximize();
//		
		//conferenceRegistrationy login = new conferenceRegistrationy(driver);
		
		//Initializing web element using initElement method
		
		conferenceRegistration login_page = PageFactory.initElements(driver, conferenceRegistration.class);
		
		login_page.login_misapp("lokesh", "babu", "lokesh@gmail.com","123456789","4","Mumbai","Maharashtra","Pune");	
		
}         
	
}