package PageFactory;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.testng.annotations.Test;


//import POM.LoginPage;
import PageFactory.LoginPageFactory;

public class NG_VerifyLoginPageFactory {

	
	public int TimeoutValue = 30;
    @BeforeClass
    public void establishDriver()
    {
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///D:/misAppp.html");
		LoginPageFactory login_page = PageFactory.initElements(driver, LoginPageFactory.class);
		System.out.println("You've established a connection with" +driver.getTitle());
    }
	@Test
	public void veryfylogin()
	{
//	System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///D:/misAppp.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		//LoginPageFactory login = new LoginPageFactory(driver);
		
		//Initializing web element using initElement method
		
		LoginPageFactory login_page = PageFactory.initElements(driver, LoginPageFactory.class);
		login_page.login_misapp("capgemini", "capgemini", "capgemini");	
		
}         
	
	
}