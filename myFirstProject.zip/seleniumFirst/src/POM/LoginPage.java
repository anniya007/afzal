package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;

public class LoginPage 
{
	WebDriver driver;	
	By username= By.id("txtUserName");
	By password = By.xpath("//*[@id='txtPassword']");
	By title= By.xpath("/html/body/h1");
	//By header=By.xpath(xpathExpression)

	//creating parameterized constructor to initialize WebDriver reference
	public LoginPage(WebDriver driver)
	{
		this.driver =driver;
	}
	public void typeusername() throws InterruptedException
	{
		driver.findElement(username).sendKeys("Afzal");
		System.out.println("username located");
		Thread.sleep(2000);
	}

	public void typepassword() throws InterruptedException 
	{
		driver.findElement(password).sendKeys("capgemini");
		System.out.println("password located");
		Thread.sleep(2000);
	}
	public void validateTitle() throws InterruptedException 
	{
		//driver.findElement(title).isDisplayed();
		String expected_result=driver.findElement(title).getText();
		String actual_title= "Email Registration";
		if(expected_result.equals(actual_title))
		{
			System.out.println("title located and matched as well");
		}
		//System.out.println("title located");
		Thread.sleep(2000);
	}
	public void validateHeader() throws InterruptedException 
	{
		driver.findElement(password).sendKeys("capgemini");
		System.out.println("password located");
		Thread.sleep(2000);
	}

	public static void main(String args[]) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("D:\\misAppp.html");
		
		driver.manage().window().maximize();
		
		LoginPage login = new LoginPage(driver);
		login.typeusername();
		login.typepassword();
		login.validateTitle();
	}
}
