package com.registration.service;

 /*******Author Name: Afzal JV Emp Id : 158017 Date: 28.9.2018 ******/
//Purpose: To create File System for adding & displaying Video details


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


import com.registration.bean.RegistrationDetails;

public class RegistrationFileHelper
{
	public RegistrationFileHelper(){}
	
	//adding registration details to the file system
	public void addNewApplicant(RegistrationDetails RegistrationDetails) 
	{			
		try{
			FileOutputStream fos= new FileOutputStream("mark1.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(RegistrationDetails);
			oos.close();
			fos.close();
		}
		catch (IOException e)
		{	
		}
	}
	//displaying all Video details
	public void displayAllRegistration()
	{
		try{
			FileInputStream fis= new FileInputStream("mark1.txt");
		
		  ObjectInputStream ois = new ObjectInputStream(fis);
		  RegistrationDetails s2= new RegistrationDetails();
		  s2=(RegistrationDetails)ois.readObject();
		  s2.ddisplay();
		  ois.close();
		  fis.close();	  
		}
		catch(IOException e)
		{
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
