package com.registration.service;

/*******Author Name: Afzal JV Emp Id : 158017 Date: 28.9.2018 ******/
//Purpose: To provide data validation for the user input

import java.util.regex.Pattern;

import com.registration.exception.RegistrationException;


public class RegistrationValidator
{
	//validating Full name - it should be alphanumeric and minimum 6 and max 25 alphabets long.
	public  static  boolean validatefullName(String fullName)throws RegistrationException
	{
		String assetPattern="[A-Za-z\\s]{6,25}";
		if(Pattern.matches(assetPattern, fullName))
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Full name should be alphabets only and minimum 6 alphabets and max 25 alphabets with a space allowed in between.");
		}
	}
	

	//validating City and State name - it should be alphanumeric and minimum 6 and max 25 alphabets long.
	public  static  boolean validatecitystateName(String cityState)throws RegistrationException
	{
		String assetPattern="[A-Za-z\\s]{8,30}";
		if(Pattern.matches(assetPattern, cityState))
		{
			return true;
		}
		else
		{
			throw new RegistrationException("City & State name should be alphabets only and minimum 8 alphabets and max 30 alphabets with a space and comma allowed in between.");
		}
	}
	//validating Mobile number
	public  static  boolean validatemobileNo(String mobileNo)throws RegistrationException
	{
		String assetPattern="[7-9][0-9]{9}";
		if(Pattern.matches(assetPattern, mobileNo))
		{
			return true;
		}
		else
		{
			throw new RegistrationException("\nMobile No. should be only 10-digit number starting with 7 / 8 / 9. Let's try again.\n");
		}
	}
	//validating Participant type - it should be Student, Professor or IT professional
	public  static  boolean validateparticipantType(String participantType)throws RegistrationException
	{
		if(participantType.equalsIgnoreCase("Student")||(participantType.equalsIgnoreCase("Professor")||(participantType.equalsIgnoreCase("IT professional"))))
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Participant type should be either Student, professor or IT professional only");
		}
		
	}
	
	//validating Video quantity - it should be of number and minimum 5, maximum 30 
	public  static  boolean validatefees(String fees)throws RegistrationException
	{
		String qtyPattern="[0-9]";
		if(Pattern.matches(qtyPattern,fees))
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Fees should be 500/- for Student, 1000/- for Professor and 1500/- for IT professional");
		}
	}

}
