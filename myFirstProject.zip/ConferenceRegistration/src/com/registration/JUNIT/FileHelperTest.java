package com.registration.JUNIT;

import JUNIT.framework.Assert;

import org.junit.AfterClass;
import com.registration.JUNIT.BeforeClass;
import junit.Test;

import com.registration.bean.RegistrationDetails;
import com.registration.exception.RegistrationException;
import com.registration.service.RegistrationFileHelper;

public class FileHelperTest
{
	static RegistrationFileHelper RegistrationFileHelper;
	static RegistrationDetails all=null;

	//adding asset details to the array list
	@BeforeClass
	
	public   static  void beforeClass()
	{
		RegistrationFileHelper=new RegistrationFileHelper();
		all=new RegistrationDetails();		
	}
	
	//clearing the arraylist
	@AfterClass
	
	public static  void afterClass()
	{		
		RegistrationFileHelper=null;
		all=null;
	}	
	
	//checking whether asset details are present in array list
	@Test 
	public void testAddNewBook() throws RegistrationException
	{
		RegistrationFileHelper.addNewApplicant(all);
		Assert.assertNotNull(all.getregistrationID());
	}

}
