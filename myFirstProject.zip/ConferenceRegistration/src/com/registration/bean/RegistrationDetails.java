package com.registration.bean;

public class RegistrationDetails 
{

	private String fullName;
	private String orgName;
	private String cityState;	
	private String mobileNo;
	private String participantType;
	private String fees;
	private long registrationID;
	

	
	public RegistrationDetails() {

	}
	
	//initializing instance variables
	public RegistrationDetails(String fullName,String orgName, String mobileNo, String cityState,String stream, String participantType, String fees)
	{
		this.fullName = fullName;
		this.orgName = orgName;
		this.cityState = cityState;
		this.mobileNo = mobileNo;
		this.participantType = participantType;
		
	}
	
	public String getfullName() {
		return fullName;
	}
	
	public void setfullName(String fullName) {
		this.fullName = fullName;
	}
	public String getorgName() {
		return orgName;
	}
	
	public void setorgName(String orgName) {
		this.orgName = orgName;
	}
	
	public String getcityState() {
		return cityState;
	}

	public void setcityState(String cityState) {
		this.cityState = cityState;
	}
	
	public void setmobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
		public String getmobileNo() {
			return mobileNo;
	}
	//specifying the getter and setter
	public String getparticipantType() {
		return participantType;
	}
		
	public void setparticipantType(String participantType) {
		this.participantType = participantType;
	}	
	//getter for fees
	public String getfees() {
		return fees;
	}
	//setter for fees
	public String setfees(String fees) {
		return this.fees = fees;
	}	
	
	//getter for registration id
	public long getregistrationID() {
		return registrationID;
	}
	//setter for registration id
	public void setregistrationID(int registrationID) {
		this.registrationID = registrationID;
	}
	//@Override
	public void ddisplay() {
		System.out.println(" Enter Full Name:" + fullName + "\n enter Organization Name:"
				+ orgName + "\n City State =" + cityState + "\n Mobile =" + mobileNo +"\n Participant Type =" + participantType + "\n Registration Fees:"+fees+""
						+ "Your registration is recorded with Registration ID "+registrationID);
	}
}
