package com.registration.ui;

import java.util.Scanner;

import com.registration.bean.RegistrationDetails;
import com.registration.exception.RegistrationException;
import com.registration.service.RegistrationFileHelper;
import com.registration.service.RegistrationValidator;
import com.registration.ui.RegistrationClient;

public class RegistrationClient {
	static Scanner sc=new Scanner(System.in);    //scanner objects created
	static Scanner sc1=new Scanner(System.in);
	static RegistrationFileHelper RegistrationFileHelper=null;
	static String mobile;
	
	//Main method
	public static void main(String[] args) throws RegistrationException
	{
		String choice;
		RegistrationFileHelper=new RegistrationFileHelper();

		while(true)
		{
			//Providing user interface
			System.out.println("Conference Registration \n*********************** \n1. Register to the Conference\n"
					+ "2. Read Registration Details from File\n"+ "3. Exit");
			
			System.out.println("\nEnter your choice :");
			choice=sc.next();
			switch(choice)
			{
			
			//Calling registerConference method for getting & displaying University details 
			case "1":registerConference();break;
			case "2":RegistrationFileHelper.displayAllRegistration();break;
			case "3":System.out.println("Exiting...");System.exit(0);
			default: System.out.println("\nPlease enter correct choice");
			break;
			}
		}
	}
	
	//method for getting & displaying registration details
	private static void registerConference() 
	{
		System.out.println("Enter Full Name:");
		String fullName=sc1.nextLine();
		try 
		{
			
			if(RegistrationValidator.validatefullName(fullName))
			{
				System.out.println("Enter City & State Name:");
				String cityState=sc.next();
				
					if(RegistrationValidator.validatecitystateName(cityState))
					{
						System.out.println("Enter Contact Number:");
						String mobileNo=sc.next();
										
						//sending input to validateUniversityQuanity method for validating University UniversityNumber
						if(RegistrationValidator.validatemobileNo(mobileNo))
						{
							System.out.println("Enter Participant Type:");
							String participantType=sc.next();
														
							if(RegistrationValidator.validateparticipantType(participantType))
							{
								System.out.println("Enter Registration Fees :");
								String fees=sc.next();

								if(RegistrationValidator.validatefees(fees))
								{
						
									RegistrationDetails cc=new RegistrationDetails(fullName, cityState, mobileNo, participantType, fees, fees, fees);
						
									RegistrationFileHelper.addNewApplicant(cc);
						
									RegistrationFileHelper.displayAllRegistration();
								}
							}
						}	
					}
				}
			
			} 
		catch (RegistrationException e)
		{			
			System.out.println(e.getMessage());
		}
}
}