package com.cg.university.bean;

public class RegistrationDetails 
{

	private String fullName;
	private String orgName;
	private String cityState;	
	private String mobileNo;
	private String stream;
	private String participantType;
	private int fees;
	

	
	public RegistrationDetails() {

	}
	
	//initializing instance variables
	public RegistrationDetails(String fullName,String orgName, String mobileNo, String cityState,String stream, String participantType, int fees)
	{
		this.fullName = fullName;
		this.orgName = orgName;
		this.cityState = cityState;
		this.mobileNo = mobileNo;
		this.participantType = participantType;
		
	}
	
	
	public String getparticipantType() {
		return participantType;
	}
	
	public void setparticipantType(String participantType) {
		this.participantType = participantType;
	}
	
	public String getfullName() {
		return fullName;
	}
	
	public void setfullName(String fullName) {
		this.fullName = fullName;
	}
	public String getorgName() {
		return orgName;
	}
	
	public void setorgName(String orgName) {
		this.orgName = orgName;
	}
	
	public String getcityState() {
		return cityState;
	}

	public void setcityState(String cityState) {
		this.cityState = cityState;
	}
	
	public void setmobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
		public String getmobileNo() {
			return mobileNo;
	}
		
	public int getfees() {
		return fees;
	}
		
	public void setfees(int fees) {
		this.fees = fees;
	}	
	
	@Override
	public String toString() {
		return " Enter Full Name:" + fullName + "\n enter Organization Name:"
				+ orgName + "\n City State =" + cityState + "\n Mobile =" + mobileNo +\n Participant Type =" + participantType + "\n" ;
	}
}
