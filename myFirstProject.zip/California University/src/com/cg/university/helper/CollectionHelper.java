package com.cg.university.helper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.university.bean.AdmissionDetails;
import com.cg.university.exception.AdmissionException;
import com.cg.university.helper.CollectionHelper;


public class CollectionHelper
{
	//creating array list and adding default data
	private  static ArrayList<AdmissionDetails> studentList=null;  //arrayList object created
	private Scanner scan;
	static
	{
		studentList=new ArrayList<AdmissionDetails>();
	
	}
	
	public CollectionHelper(){}  //constructor
	
	//adding admission details to the array list
	public void addNewStudentDetails(AdmissionDetails AdmissionDetails) 
	{			
			studentList.add(AdmissionDetails);				 //we need to use write method in terms of File IO
	}
	
	public static ArrayList<AdmissionDetails> gestudentList() {
		return studentList;
	}

	public static void setstudentList(ArrayList<AdmissionDetails> studentList) {
		CollectionHelper.studentList = studentList;
	}

	//displaying all admission details
	public  void displayAllAdmissions()          //from UniversityClient.java
	{
		Iterator<AdmissionDetails> StudentIt=studentList.iterator();
		AdmissionDetails tempStudent=null;
		while(StudentIt.hasNext())
		{
			//System.out.println("You're in!");
			tempStudent=StudentIt.next();
			System.out.println(tempStudent);			
		}
	}

	public void deleteAdmissionDetails() throws AdmissionException {
		scan = new Scanner(System.in);
		System.out.println("Enter the mobile no of the registered student : ");
		String mobileNumber=scan.next();
		
		try {
			if(DataValidator.validatemobileNo(mobileNumber))
			{
					boolean isRecordMathched=false;
					
					Iterator<AdmissionDetails> StudentIt=studentList.iterator();
					AdmissionDetails tempStudent=null;
					while(StudentIt.hasNext())
					{
						tempStudent=StudentIt.next();
						if(tempStudent.getmobileNo().toString().equals(mobileNumber))
						{
								
							try
							{
								isRecordMathched=true;
								
								StudentIt.remove();
										System.out.println("Record deleted successfully...");
							}catch(Exception e)
							{
								System.out.println("Error in deleting the record");
							}
												
						}
					}
					
					if(!isRecordMathched)
					{
						System.out.println("Opps....Record not found with this number..");
					}
			}else
			{
				throw new  AdmissionException("Enter correct mobile number");
			}
		} catch (AdmissionException e) {
			// TODO Auto-generated catch block
			System.out.println(e.toString());
		}
		
	}

	public void getTotalAdmissions() {
		// TODO Auto-generated method stub
		System.out.println("Total number of students registered: "+studentList.size());
		
	}

	
	
}