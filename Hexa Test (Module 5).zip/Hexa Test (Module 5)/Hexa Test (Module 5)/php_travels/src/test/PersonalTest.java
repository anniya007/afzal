package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.phptravels.hexatest.pageobject.PersonalDetailsPage;

public class PersonalTest extends FunctionalTest {

	
	@Test
	public void  register() throws InterruptedException{
PersonalDetailsPage page = new PersonalDetailsPage(driver);
String url="http://www.phptravels.net/cars/book/Kia-Pacanto-2014?pickupLocation=7&dropoffLocation=7&pickupDate=01%2F11%2F2018&pickupTime=02%3A00&dropoffDate=02%2F11%2F2018&dropoffTime=04%3A30";
driver.get(url);
page.verifyfirstname();
page.verifylastname();
page.verifyemail();
page.verifyconfirmemail();
page.verifyphone();
page.verifyaddress();
page.submitReg();

	}
	
	
}
