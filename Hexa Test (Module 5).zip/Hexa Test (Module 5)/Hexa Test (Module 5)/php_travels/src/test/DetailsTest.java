package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.hexatest.pageobject.DetailsPage;
import com.phptravels.hexatest.pageobject.PersonalDetailsPage;

public class DetailsTest extends FunctionalTest{
	
	
	
//  @Test(priority=1)
//  public void headingTest(){
//	 
//	  DetailsPage detailsPage = new DetailsPage(driver);
//	  String actualhead=detailsPage.getHead();
//	  Assert.assertEquals(actualhead, "BOOKING OPTIONS");
//  }
  @Test(priority=1)
  public void isPicUpLocationMatching(){
	  DetailsPage detailsPage = new DetailsPage(driver);
	  driver.get("http://www.phptravels.net/cars/united-kingdom/manchester/Kia-Pacanto-2014?&pickupLocation=7&dropoffLocation=7&pickupDate=01/11/2018&pickupTime=02:00&dropoffDate=02/11/2018&dropoffTime=04:30");
	 String actualLpicLoc= detailsPage.getCurrentPickUpLocation();
	
	//  System.out.println("URL = "+driver.getCurrentUrl());
	  Assert.assertEquals(actualLpicLoc, "Manchester");
	 
  }
  
  
	
  @Test(priority=2)
  public void isDropUpLocationMatching(){
	  DetailsPage detailsPage = new DetailsPage(driver);
	  String actualdropLoc= detailsPage.getCurrentDropUpLocation();
	  Assert.assertEquals(actualdropLoc, "Manchester");
  }
  
	
  @Test(priority=3)
  public void booking() throws InterruptedException{
	  DetailsPage detailsPage = new DetailsPage(driver);

	  PersonalDetailsPage page = 	  detailsPage.bookNow();
	  Assert.assertEquals(page.getHeading(), "PERSONAL DETAILS");
	  Thread.sleep(2000);
  }
  
//  @Test(priority=4)
//  public void isPickUpDateMatching(){
//	  DetailsPage detailsPage = new DetailsPage(driver);
//	  String actualhead=detailsPage.getHead();
//	  Assert.assertEquals(actualhead, "BOOKING OPTIONS");
//  }
//	
//  @Test(priority=5)
//  public void isDropUpDateMatching(){
//	  DetailsPage detailsPage = new DetailsPage(driver);
//	  String actualhead=detailsPage.getHead();
//	  Assert.assertEquals(actualhead, "BOOKING OPTIONS");
//  }
//	
//  @Test(priority=6)
//  public void isPickUpTimeMatching(){
//	  DetailsPage detailsPage = new DetailsPage(driver);
//	  String actualhead=detailsPage.getHead();
//	  Assert.assertEquals(actualhead, "BOOKING OPTIONS");
//  }
//	
//  @Test(priority=7)
//  public void isDropUpTimeMatching(){
//	  DetailsPage detailsPage = new DetailsPage(driver);
//	  String actualhead=detailsPage.getHead();
//	  Assert.assertEquals(actualhead, "BOOKING OPTIONS");
//  }
	
}
