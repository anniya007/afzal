package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.hexatest.pageobject.HomePageCars;
import com.phptravels.hexatest.pageobject.SearchPage;

public class HomeTest extends FunctionalTest{

	XSSFWorkbook wb1;
	XSSFSheet sheet1;
	String pickuplocation;
	String dropofflocation;
	@Test(priority=2)  // to ensure this method runs second
	public void searchCarsByPickupLoc() throws InterruptedException, IOException {
		driver.get("http://www.phptravels.net");
		HomePageCars homePageCars = new HomePageCars(driver);
		
//		File src= new File("D:\\Car_Rental.xlsx");
//		//using Java API specify workbook path
//		FileInputStream fis = new FileInputStream(src);
//		//to load entire workbook use XSSFWorkbook class
//		 wb1 = new XSSFWorkbook(fis);  //XSS used for .xlsx file
//		 sheet1 = wb1.getSheetAt(1);
//		
//				//1. Launch Chrome Browser
//				driver.get("D://js-form-validation (1)//js-form-validation//example-javascript-form-validation.html");
//				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//				driver.manage().window().maximize();
//				homePageCars = PageFactory.initElements(driver, HomePageCars.class);
//		pickuplocation=sheet1.getRow(182).getCell(5).getStringCellValue();
//		dropofflocation=sheet1.getRow(183).getCell(5).getStringCellValue();
//		
//		System.out.println("------------------->>>>>>>>>"+pickuplocation);
//		System.out.println("------------------->>>>>>>>>"+dropofflocation);
//			
//		
		
		
		homePageCars.implicitwait();
		homePageCars.clickOnCarTab();
		Thread.sleep(2000);
		homePageCars.pickupLocTextBox("Man");
		homePageCars.dropupLocTextBox("Man");
	
		homePageCars.verifytime2(10);
//		Thread.sleep(1000);
		homePageCars.verifytime1(5);
//		Thread.sleep(1000);
		homePageCars.pickUpDate();
//		Thread.sleep(1000);
		homePageCars.dropUpDate();
		Thread.sleep(1000);
		SearchPage searchPage = homePageCars.submit();
		Thread.sleep(1000);
		Assert.assertEquals(searchPage.getTitle(), "Search Results");
	}
//	
	@Test(priority=1)
	public void searchFailedByPickupLoc() throws InterruptedException{
		driver.get("http://www.phptravels.net");
		HomePageCars homePageCars = new HomePageCars(driver);
		homePageCars.implicitwait();
		homePageCars.clickOnCarTab();
		Thread.sleep(1000);
		homePageCars.dropupLocTextBox("Man");
		Thread.sleep(1000);
		homePageCars.verifytime1(5);
		Thread.sleep(1000);
		homePageCars.verifytime2(10);
		Thread.sleep(1000);
		homePageCars.dropUpDate();
		Thread.sleep(1000);
		homePageCars.pickUpDate();
		Thread.sleep(1000);
		SearchPage searchPage = homePageCars.submit();
		Thread.sleep(2000);
		//homePageCars.geterrorMessage();
	}
//	
	
	
	
	
}
//
//<test name="InternetExplorer">
//<parameter name="browser" value="internetexplorer" />
//<classes>
//	<class name="test.HomeTest" />
//</classes>
//</test>