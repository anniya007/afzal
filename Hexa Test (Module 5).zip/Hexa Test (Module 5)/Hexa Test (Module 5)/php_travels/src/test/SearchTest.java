package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.hexatest.pageobject.DetailsPage;
import com.phptravels.hexatest.pageobject.HomePageCars;
import com.phptravels.hexatest.pageobject.SearchPage;

public class SearchTest extends FunctionalTest{

	@Test(priority=1)  // to ensure this method runs second
	public void applyFilter() throws InterruptedException {
		String str="http://www.phptravels.net/cars/search?pickupLocation=7&dropoffLocation=7&pickupDate=01%2F11%2F2018&pickupTime=02%3A00&dropoffDate=02%2F11%2F2018&dropoffTime=04%3A30";
		driver.get(str);
		SearchPage searchPage = new SearchPage(driver);
		Thread.sleep(1000);
		searchPage.verifystarGrade();
		//searchPage.verifypriceRange();
		searchPage.verifcarType();
		//searchPage.verifyairportPickUp();
		
		//searchPage.select_pickUp(1);
		searchPage.search();
		Thread.sleep(2000);
		Assert.assertEquals(searchPage.getTitle(), "Search Results");
}
	@Test(priority=2)  // to ensure this method runs second
	public void getDetails() throws InterruptedException {
		String str="http://www.phptravels.net/cars/search?pickupLocation=7&dropoffLocation=7&pickupDate=01%2F11%2F2018&pickupTime=02%3A00&dropoffDate=02%2F11%2F2018&dropoffTime=04%3A30";
		driver.get(str);
		SearchPage searchPage = new SearchPage(driver);
		Thread.sleep(1000);
	
		DetailsPage detailsPage = 	searchPage.showDetails();
		Assert.assertEquals(detailsPage.getHead(), "BOOKING OPTIONS");
		
}
}
