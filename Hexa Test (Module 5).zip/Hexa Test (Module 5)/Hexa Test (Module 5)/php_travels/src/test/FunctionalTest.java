package test;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class FunctionalTest {
	protected RemoteWebDriver driver;

	@Parameters("browser")
	@BeforeClass
	public void setupDriver(String browser) throws MalformedURLException {
		// will handle 2 major browsers: FireFox & Chrome
		DesiredCapabilities dc = null;
String address="";
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
			dc = DesiredCapabilities.chrome();
			dc.setBrowserName("chrome");
			address="http://localhost:6666/wd/hub";

		} 
//		else if (browser.equalsIgnoreCase("firefox")) {
//			dc = DesiredCapabilities.firefox();
//			dc.setBrowserName("firefox");
//			System.setProperty("webdriver.firefox.bin","C:\\Users\\kartikks\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
//			FirefoxProfile profile = new FirefoxProfile();
//			profile.setPreference("newtwork.proxy.type",1);
//			profile.setPreference("newtwork.proxy.http","chnproxy.igate.com");
//			profile.setPreference("newtwork.proxy.http_port",8080);
//			profile.setPreference("network.proxy.ssl", "chnproxy.igate.com");
//			profile.setPreference("network.proxy.ssl_port", 8080);
//			dc.setCapability(FirefoxDriver.PROFILE, profile);
//			address="http://localhost:5557/wd/hub";
//		}
		else if(browser.equalsIgnoreCase("internetexplorer")){
			// FOR IE BROWSER	
			System.setProperty("webdriver.ie.driver","D:\\IEDriverServer.exe");
			dc = DesiredCapabilities.internetExplorer();
			dc.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			dc.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			address="http://localhost:6668/wd/hub";
		}

		dc.setPlatform(Platform.WINDOWS);
		driver = new RemoteWebDriver(new URL(address), dc);
		driver.manage().window().maximize();
	}

	@AfterClass
	public void quitDriver() {
		driver.quit();
	}
}

