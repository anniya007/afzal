package Question1;

//testNG program

//import java.util.concurrent.TimeUnit;
//
//import junit.framework.Assert;
//
//import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Question1.Page_Factory;

public class Page_Factory_Test_NG {
	
	WebDriver driver ;
	Page_Factory pageFactory;
	public int TimeoutValue = 30;
			
	
	
	@Test(priority=1)
	public void TestCaseOne() throws InterruptedException
	{
		//1.	Launching the application browser, Chrome
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		//2.	Open the web page �Registration Form.html � in the browser.
		driver.get("D:\\example-javascript-form-validation.html");
		pageFactory = PageFactory.initElements(driver, Page_Factory.class);
		
		//3.	Verify the title �Registration Form� of the page. 
		//The test should stop execution if the title of the page is not matching with the expected title.
		pageFactory.verifyTitle("JavaScript Form Validation using a sample registration form");
		
		//4. Verify that each of the respective fields are present on the web page.
		
	}         
	@Test(priority=2)
	public void TestCaseTwo() throws InterruptedException
	{
        //For User ID
		pageFactory.verifyuserID();
		

		//For Password
		pageFactory.verifyPassword();
		
		//For Name
		pageFactory.verifyName();
		
	}
	@Test(priority=3)
	public void TestCaseThree() throws InterruptedException
	{
		
		//For Address
		pageFactory.verifyAddress();
		
/*		  For Country
		pageFactory.verifyCountry(2);*/
	}
}
